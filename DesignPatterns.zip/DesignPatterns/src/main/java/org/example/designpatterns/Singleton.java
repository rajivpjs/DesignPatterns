package org.example.designpatterns;

public class Singleton {

    private static Object object = null;

    private Singleton() {
        System.out.println("Called constructor");
        // provided so that it can not be institated from outside
    }

    public static Object getSingleton() {
        if(object == null) {
            return new Singleton();
        }

        return object;
    }

    public static void main(String[] args) {
        Object object = Singleton.getSingleton();
        System.out.println(object);
    }
}
